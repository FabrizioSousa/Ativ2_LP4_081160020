﻿
///////  QUANDO LOADA A PAGINA //////////////////////
(function ()  // é os <script> da vida com todos os <script>
{
    'use strict';

    angular
        .module('app')
        .controller('Perguntas.IndexController', Controller); //inicia quando loada (Sintaxe importante p P)
       
    function Controller($window, UserService, FlashService) {
  
      var vm = this;

        vm.GravaPergunta = GravaPergunta; //"instanciar" function
        
        vm.DeletaPergunta = DeletaPergunta;
    
        function GravaPergunta()
        {
            // var table = document.getElementById("lista");
            // var row = table.insertRow(table.length);
            var pergunta = document.getElementById('pergunta').value;
            // // Insert new cells (<td> elements) at the 1st and 2nd position of the "new" <tr> element:
            // var cell1 = row.insertCell(0);
            
            // // Add some text to the new cells:
            // cell1.innerHTML ="<a  class='list-group-item'" + pergunta + "</a>";
          
           var a = document.createElement("a");
          
           a.setAttribute("name","a");
           a.setAttribute("class","list-group-item");
          
          
         
           a.innerHTML = pergunta;
          // li_nova.innerHTML = document.getElementsByName("b")[0];
          // console.log(document.getElementsByName("b")[0]);
          // console.log(li_nova.innerHTML);
          //   // + "<br>"
          //   ;
           var table = document.getElementById("lista");
          //   table.appendChild(li_nova);
          
            table.appendChild(a);
            
        } 

      

        function DeletaPergunta()
        {
          

          var x =document.getElementsByName("a")[0];
          console.log(x.getAttribute("name"));
          x.remove();
          
          // var rowindex;
          // var table = document.getElementById("lista");
          // for(var x = 1;x<table.rows.length;x++)
          // {
          //   table.rows[x].onclick = function()
          //   {
          //       rowindex = this.rowindex;
          //       console.log(rowindex);
          //   };       
            
          // }
          //  var row = btn.parentNode.parentNode;
          // var table = document.getElementById("lista");
          // table.deleteRow(1);
            // table.deleteRow(1);
            // row.parentNode.removeChild(row);
       
         
           
        } 
         
    }
    
    


})();
